class Server:
    def __init__(self, name, core, memory, price, cost):
        self.name = name
        self.core = core
        self.memory = memory
        self.price = price
        self.cost = cost
        self.vm = []
        if core % 2 != 0 or memory % 2 != 0:
            raise Exception("Server requires even core and memory requirements.")
        self.A_available_core = core / 2
        self.A_available_memory = memory / 2
        self.B_available_core = core / 2
        self.B_available_memory = memory / 2

    def get_available_core(self):
        return self.A_available_core + self.B_available_core

    def set_available_core(self, num: int, node: str):
        if num < 0:
            raise Exception("Available core can not less than zero!")
        elif node == "A":
            self.A_available_core = num
        elif node == "B":
            self.B_available_core = num
        else:
            raise Exception("Specify the correct node.")

    def get_available_memory(self):
        return self.A_available_memory + self.B_available_memory

    def set_available_memory(self, num: int, node: str):
        if num < 0:
            raise Exception("Available memory can not less than zero!")
        elif node == "A":
            self.A_available_memory = num
        elif node == "B":
            self.B_available_memory = num
        else:
            raise Exception("Specify the correct node.")

    def allocate(self, core_num: int, memory_num: int, node):
        if core_num < 0 or memory_num < 0:
            raise Exception("Allocate core or memory can not less than zero!")
        if node == "A":
            remain_core = self.A_available_core - core_num
            remain_memory = self.A_available_memory - memory_num
            if remain_core >= 0 and remain_memory >= 0:
                self.A_available_core = remain_core
                self.A_available_memory = remain_memory
                return True
        elif node == "B":
            remain_core = self.B_available_core - core_num
            remain_memory = self.B_available_memory - memory_num
            if remain_core >= 0 and remain_memory >= 0:
                self.B_available_core = remain_core
                self.B_available_memory = remain_memory
                return True
        else:
            raise Exception("Specify the correct node.")
        return False

    def is_running(self):
        return False if len(self.vm) == 0 else True


class VM:
    def __init__(self, name, core, memory, is_dual):
        self.name = name
        self.core = core
        self.memory = memory
        self.is_dual = is_dual
        if is_dual:
            if core % 2 != 0 or memory % 2 != 0:
                raise Exception("Dual node virtual machines require even core and memory requirements.")


class Schedule:
    def __init__(self):
        self.server_list = []  # server type
        self.vm_list = []  # vm type
        self.own_server_list = []  # owned servers, like [(0, NV603), (1, NV604)]
        self.next_server_id = 0  # the ID of the next server
        self.total_cost = 0  # the sum of purchasing servers and energy consumption
        self.purchase_server_one_day = {}
        self.vm_deploy_one_day = []

    def get_vm_by_name(self, vm_name):
        """
        In the virtual machine list, look up the virtual machine according to the type name of the virtual machine.
        :param vm_name: the type name of the virtual machine
        :return: If found, it will return the virtual machine; otherwise, it will None.
        """
        for vm in self.vm_list:
            if vm.name == vm_name:
                return vm
        return None

    def purchase_server(self):
        s = self.server_list[74]
        server_purchase = Server(s.name, s.core, s.memory, s.price, s.cost)
        self.own_server_list.append((self.next_server_id, server_purchase))
        self.next_server_id += 1
        self.total_cost += server_purchase.price
        if server_purchase.name in self.purchase_server_one_day.keys():
            self.purchase_server_one_day[server_purchase.name] += 1
        else:
            self.purchase_server_one_day[server_purchase.name] = 1

    def add_vm(self, vm_name, vm_id):
        is_need_purchase = True
        vm = self.get_vm_by_name(vm_name)
        if vm is None:
            raise Exception("No this type vm.")
        for server_id, server in self.own_server_list:
            if not vm.is_dual:
                if server.allocate(vm.core, vm.memory, "A"):
                    server.vm.append((vm_id, "A", vm))
                    self.vm_deploy_one_day.append((server_id, "A"))
                    is_need_purchase = False
                    break
                if server.allocate(vm.core, vm.memory, "B"):
                    server.vm.append((vm_id, "B", vm))
                    self.vm_deploy_one_day.append((server_id, "B"))
                    is_need_purchase = False
                    break
            else:  # vm.is_dual == True
                core_on_each_node = vm.core / 2
                memory_on_each_node = vm.memory / 2
                if server.allocate(core_on_each_node, memory_on_each_node, "A") and \
                        server.allocate(core_on_each_node, memory_on_each_node, "B"):
                    server.vm.append((vm_id, "", vm))
                    self.vm_deploy_one_day.append((server_id, ""))
                    is_need_purchase = False
                    break
        if is_need_purchase:
            self.purchase_server()
            self.add_vm(vm_name, vm_id)

    def delete_vm(self, vm_id):
        for server_id, server in self.own_server_list:
            for i, vm in enumerate(server.vm):
                if vm[0] == vm_id:  # vm is a tuple, like (vm_id, "A", vm)
                    core = vm[2].core
                    memory = vm[2].memory
                    is_dual = vm[2].is_dual
                    if not is_dual:
                        if vm[1] == "A":
                            server.set_available_core(server.A_available_core + core, "A")
                            server.set_available_memory(server.A_available_memory + memory, "A")
                            del server.vm[i]
                            return True
                        elif vm[1] == "B":
                            server.set_available_core(server.B_available_core + core, "B")
                            server.set_available_memory(server.B_available_memory + memory, "B")
                            del server.vm[i]
                            return True
                        else:
                            raise Exception("Specify the correct node.")
                    else:  # is_dual == True
                        server.set_available_core(server.A_available_core + core / 2, "A")
                        server.set_available_memory(server.A_available_memory + memory / 2, "A")
                        server.set_available_core(server.B_available_core + core / 2, "B")
                        server.set_available_memory(server.B_available_memory + memory / 2, "B")
                        del server.vm[i]
                        return True
        raise Exception("The virtual machine with the specified ID to be deleted does not exist.")

    def migrate_vm(self):
        pass

    def main(self):
        server_number = int(input())
        for s in range(server_number):
            param = input().strip("()\r\n ").split(",")
            param = [p.strip() for p in param]
            self.server_list.append(Server(param[0], int(param[1]), int(param[2]), int(param[3]), int(param[4])))

        vm_number = int(input())
        for v in range(vm_number):
            param = input().strip("()\r\n ").split(",")
            param = [p.strip() for p in param]
            self.vm_list.append(VM(param[0], int(param[1]), int(param[2]), int(param[3])))

        days = int(input())
        for d in range(days):
            quest_number = int(input())
            for q in range(quest_number):
                quest = input().strip("()\r\n ").split(",")
                quest = [q.strip() for q in quest]
                if quest[0] == "add":
                    self.add_vm(quest[1], quest[2])
                elif quest[0] == "del":
                    self.delete_vm(quest[1])
                else:
                    raise Exception("ERROR: Unknown operation.")

            print("(purchase, %d)" % len(set(self.purchase_server_one_day.keys())))
            for key, value in self.purchase_server_one_day.items():
                print("(%s, %d)" % (key, value))
            print("(migration, 0)")
            for s_id, node in self.vm_deploy_one_day:
                if node == "":
                    print("(%d)" % s_id)
                else:
                    print("(%d, %s)" % (s_id, node))
            self.purchase_server_one_day = {}
            self.vm_deploy_one_day = []


if __name__ == "__main__":
    schedule = Schedule()
    schedule.main()
